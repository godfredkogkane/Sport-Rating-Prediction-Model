# Importing relevant libraries
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import streamlit as st
import joblib
import pandas as pd

# Loading the trained model and scaler
model = joblib.load('trained_model.pkl')
scaler = joblib.load('scaler.pkl')

# Create a function to predict player ratings
def predict_rating(features):
    features = pd.DataFrame(features).T  # Converting feature list to a DataFrame
    features = scaler.transform(features)  # Scaling the features
    prediction = model.predict(features)
    return prediction


# Streamlit UI
st.title('Football Player Rating Prediction :soccer:')
st.markdown('Enter the features to predict the player rating.')
feature_names = ['movement_reactions', 'value_eur', 'release_clause_eur', 'mentality_composure', 'wage_eur',
                 'passing', 'potential', 'dribbling', 'power_shot_power', 'mentality_vision', 'attacking_short_passing',
                 'skill_long_passing', 'physic', 'age', 'skill_ball_control', 'shooting', 'international_reputation',
                 'skill_curve', 'attacking_crossing', 'power_long_shots', 'mentality_aggression']

user_inputs = [st.number_input(feature, value=0.0, key=feature) for feature in feature_names]

if st.button('Predict Rating'):
    prediction = predict_rating(user_inputs)
    st.markdown(f'*Predicted Rating:* {prediction[0]:.2f}', unsafe_allow_html=True)

    # Loading y_test and y_pred from the CSV file
    df = pd.read_csv('C:/Users/godfr/OneDrive - Ashesi University/DOCUMENTS/YEAR 2, SEMESTER 2/INTRODUCTION TO AI/Group Project/y_test_and_y_pred.csv')
    y_test = df['y_test'].values
    y_pred = df['y_pred'].values

    # Calculating metrics
    mse = mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    # Displaying metrics
    st.write(f'MSE: {mse:.4f}')
    st.write(f'MAE: {mae:.4f}')
    st.write(f'R-squared: {r2:.4f}')